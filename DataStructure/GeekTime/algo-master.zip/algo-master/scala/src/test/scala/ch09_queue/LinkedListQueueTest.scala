package ch09_queue

class LinkedListQueueTest extends DemoQueueTest {

  override def getInstance() = new LinkListQueue[Int]

}
